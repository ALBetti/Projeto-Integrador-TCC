<!DOCTYPE html>
<html>
<head>
	<div id="Fundo-externo">		
	<div id="Fundo">		
	</div>		
	<title>Meu Perfil</title>
	<meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="PaginaPerfil_Projeto.css">
</head>
<body>
	<nav id="Paginas">
		<ul>
			<li><a href="PaginaInicial_Projeto.php">Inicio</a></li>
			<li><a href="PaginaChat_Projeto.php">Chat</a></li>
			<li><a href="PaginaGrupos_Projeto.php">Grupos</a></li>
			<li><a href="PaginaAjuda_Projeto.php">Ajuda</a></li>
			<li><a href="PaginaBusca_Projeto.php">Busca</a></li>
			<li><a href="PaginaDenuncias_Projeto.php">Denuncias</a></li>
			</ul>		
	</nav>	
	<div class="centro">
	<div class="box1">

	<p class="img"><img src="Pessoa.png" alt="Você" title="Você" width="30%" height="30%" border="1px"  /></p>
<p><?php

	print "Nome: $nome \n";

	?></p>
	</br>
	<p><?php
	print "Sexo: $sexo \n";
	?></p>
	</br>
	<p><?php
	print "Idade: $idade\n";
	?></p>
	</br>
	<p><?php
	print "Telefone: $fone \n";
	?></p>
	</br>
	<p><?php
	print "Tipo de usuario: $tipo \n";

?></p>
</body>
</html>