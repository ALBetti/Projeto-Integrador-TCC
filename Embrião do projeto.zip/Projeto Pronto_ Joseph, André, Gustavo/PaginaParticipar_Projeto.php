<!DOCTYPE html>
<html>
<head>
	<div id="Fundo-externo">		
	<div id="Fundo">		
	</div>
	<title> Participar de um grupo</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="PaginaPosts_Projeto.css">
</head>
<body>
		<nav id="Paginas">
		<ul>
			<li><a href="PaginaInicial_Projeto.php">Inicio</a></li>
			<li><a href="PaginaChat_Projeto.php">Chat</a></li>
			<li><a href="PaginaGrupos_Projeto.php">Grupos</a></li>
			<li><a href="PaginaAjuda_Projeto.php">Ajuda</a></li>
			<li><a href="PaginaBusca_Projeto.php">Busca</a></li>
			<li><a href="PaginaDenuncias_Projeto.php">Denuncias</a></li>
			<li><a href="PaginaMeuPerfil_Projeto.php">Perfil</a></li>
		</ul>		
	</nav>
<div class="centro">
<div class="box1">
<h1>
<?php 
print "Parabéns, Você entrou no grupo $gpname com sucesso.";
$gp = 1;
//apesar de ficar estranho, entrar em grupos não requer permissões ou coisa do tipo, é como se vocÊ fosse seguir uma pagina no facebook
?>
</h1>
<p><a href="PaginaInicial_Projeto.php">Voltar</a></p>
<p><a href="PaginaGrupos_Projeto.php">Ir para página de grupos</a></p>

</body>
</html>