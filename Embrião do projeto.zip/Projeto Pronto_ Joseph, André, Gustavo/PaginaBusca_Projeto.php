<!DOCTYPE html>
<html>
<head>
	<div id="Fundo-externo">		
	<div id="Fundo">		
	</div>
	<meta charset="UTF-8">
	<title>Busca</title>
    <link rel="stylesheet" type="text/css" href="PaginaBusca_Projeto.css">
</head>
<body>
	<nav id="Paginas">
		<ul>
			<li><a href="PaginaInicial_Projeto.php">Inicio</a></li>
			<li><a href="PaginaChat_Projeto.php">Chat</a></li>
			<li><a href="PaginaGrupos_Projeto.php">Grupos</a></li>
			<li><a href="PaginaAjuda_Projeto.php">Ajuda</a></li>
			<li><a href="PaginaDenuncias_Projeto.php">Denuncias</a></li>
			<li><a href="PaginaMeuPerfil_Projeto.php">Perfil</a></li>
		</ul>		
	</nav>
	<div class="centro">
	<div class="box1">
  <h1>Aqui você pode buscar por Posts, Grupos ou Nome de Profissionais</h1>
	<form method="post" action="PaginaResult_Projeto.php">
</br>
  <p>Busca de Posts<input type="text" name="tbusca" id="cbusca" size="30"
  maxlength="60" placeholder="Digite aqui" type="cbusca" requiredss/> </p>
   	<p><input type="submit" value="Buscar"></p>
</br>
  <p>Busca de Grupos<input type="text" name="tbusca" id="cbusca" size="30"
  maxlength="60" placeholder="Digite aqui" type="cbusca" requiredss/> </p>
   	<p><input type="submit" value="Buscar"></p>
</br>
  <p>Busca de Profissionais<input type="text" name="tbusca" id="cbusca" size="30"
  maxlength="60" placeholder="Digite aqui" type="cbusca" requiredss/> </p>
   	<p><input type="submit" value="Buscar"></p>

</div>
</div>
</body>
</html>
