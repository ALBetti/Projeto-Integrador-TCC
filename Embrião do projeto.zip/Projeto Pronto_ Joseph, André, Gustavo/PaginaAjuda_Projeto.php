<!DOCTYPE html>
<html>
<head>
	<div id="Fundo-externo">		
	<div id="Fundo">		
	</div>
	<meta charset="UTF-8">
	<title>Ajuda</title>
    <link rel="stylesheet" type="text/css" href="PaginaAjuda_Projeto.css">
</head>
<body>
	<nav id="Paginas">
		<ul>
			<li><a href="PaginaInicial_Projeto.php">Inicio</a></li>
			<li><a href="PaginaChat_Projeto.php">Chat</a></li>
			<li><a href="PaginaGrupos_Projeto.php">Grupos</a></li>
			<li><a href="PaginaBusca_Projeto.php">Busca</a></li>
			<li><a href="PaginaDenuncias_Projeto.php">Denuncias</a></li>
			<li><a href="PaginaMeuPerfil_Projeto.php">Perfil</a></li>
		</ul>		
	</nav>
	<div class="centro">
	<div class="box1">
	<h1>Necessita de ajuda com o site?</h1>
	<p>Aqui está o FAQ (frequently asked questions) do nosso site, talvez sua pergunta já tenha sido respondida!</p>
	<fieldset id="FAQ"><legend>FAQ</legend>
	<h3>1 - Como me torno um administrador?</h3>
	<p> O unico jeito de se tornar um administrador é se outro adm (ou eu mesmo dono do site) lhe dar esse cargo.</p>
	<h3>2 - Existe um jeito de ser banido/banir contas?</h3>
	<p> Sim, mas só o adm pode banir contas. Ele o fará a qualquer momento que alguém falte respeito com o próximo ou faça algo imoral.</p>
	<h3>3 - Meu amigo tem problemas com depressão, eu não sei como ajuda-lo e ele não quer fazer uma conta! O que eu faço?</h3>
	<p> Você pode criar uma conta de ajudante e conversar com um profissional, este recomendará coisas para você falar a seu amigo.</p>
</fieldset>
	<p>Caso ainda tenha perguntas, mande um email para Esseemailnãoexiste@Emailzin.com ou fale conosco via whatsapp, o numero é 98888-8888.</p>

</body>
</html>
