<!DOCTYPE html>
<html>
<head>
	<div id="Fundo-externo">		
	<div id="Fundo">		
	</div>
	<meta charset="UTF-8">
	<title>Quase lá</title>
    <link rel="stylesheet" type="text/css" href="PaginaConfirmar_Projeto.css">
</head>
<body>
	<div class="centro">
	<div class="box1">
<?php  
$codigo = 1;
$nome = $_POST['tNome'];
$email = $_POST['tMail'];
$senha = $_POST['tSenha'];
$sexo = $_POST['tSexo'];
$nasc = $_POST['tNasc'];
$fone = $_POST['tFone'];
$tipo = $_POST['tTipo'];

if ($codigo = 6789) {
 ?>
 <h1>Cadastrado com sucesso!</h1>
 <p><a href="PaginaPrincipal_Projeto.php">Voltar ao Inicio</a></p>
<?php
}
elseif ($codigo < $numeroR or $codigo > $numeroR) {
	?>
 <h1>Codigo digitado incopativel</h1>

 <?php 
}

print " Caro $nome";
$numeroR = rand(1000,9999);

ini_set('display_errors', 1);

error_reporting(E_ALL);

$from = "josephhgodin@gmail.com";

$to = $email;

$subject = "Cadastro em Dnad";

$message = "Olá". $nome ."aqui está o codigo para que possa confirmar seu cadastro". $numeroR . "Se não reconhece esse site ou tentativa de cadastro, por favor, ignore esse email.";

$headers = "De:". $from;

mail($to, $subject, $message, $headers);

?>
<h1>Quase Lá!</h1>
</br>
<p>Nós mandamos um email contendo um codigo para você para confirmar sua identidade.
	(caso tenha selecionado "Profissional" o email pedira uma comprovação por escrito e só depois que a recebermos, seu codigo será enviado, mais informações no proprio email)
</p>
</br>
</br>

	<form action="<?php echo $_SERVER['PHP_SELF']?>">
	 <p>Codigo:<input type="text" name="tCodigo" id="cCodigo" size="20"
 	 maxlength="30" placeholder="Digite o codigo" type="cCodigo" required/></p>
 	</br>
 	 <p><input type="submit" value="Confirmar"></p>

</div>
</div>
</body>
</html>
