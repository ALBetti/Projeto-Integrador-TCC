<!DOCTYPE html>
<html>
<head>
	<div id="Fundo-externo">		
	<div id="Fundo">		
	</div>
	<meta charset="UTF-8">
	<title>Denuncias</title>
    <link rel="stylesheet" type="text/css" href="PaginaDenuncias_Projeto.css">
</head>
<body>
	<nav id="Paginas">
		<ul>
			<li><a href="PaginaInicial_Projeto.php">Inicio</a></li>
			<li><a href="PaginaChat_Projeto.php">Chat</a></li>
			<li><a href="PaginaGrupos_Projeto.php">Grupos</a></li>
			<li><a href="PaginaAjuda_Projeto.php">Ajuda</a></li>
			<li><a href="PaginaBusca_Projeto.php">Busca</a></li>
			<li><a href="PaginaMeuPerfil_Projeto.php">Perfil</a></li>
		</ul>		
	</nav>
	<div class="centro">
			<div class="box1">
	<?php
	$denuncia = $_POST['tDenuncia'];
	$adendo = $_POST['tMsg'];
	if ($denuncia)
	//algo para confirmar se deu certo
	 {
		?>
		<h1>Denuncia enviada com sucesso, iremos avalia-la e se a aprovarmos, a pessoa será punida.</h1>
	<?php
}
	elseif($adendo = 1)
		//condição que endica que o digitado esta incorreto 
	{
		?>

		<?php

	} 
	?>


	<h1>Aqui você poderá denunciar outros usuarios para que possam ser punidos por um administrador. Por favor seja sensato ao denunciar alguém.</h1>
	<form method="post" action="<?php echo $_SERVER['PHP_SELF']?>">
<fieldset>
 	 <p>Nome de usuario da pessoa a ser denunciada: <input type="text" name="tNomeDen" id="cNomeDen" size="20"
 	 maxlength="30" placeholder="Nome de usuario" type="cNomeDen" required/> </p>
</fieldset>
	<fieldset id="Denuncia"> <legend>Selecione o motivo da denuncia</legend></br>
        <input type="radio" name="tDenuncia" id="cAbuso"/>
        <label for="cAbuso"> Abuso</label> </br>
        <input type="radio" name="tDenuncia" id="cSpam" />
        <label for="cSpam"> Spam</label>
        <input type="radio" name="tDenuncia" id="Outros"/>
        <label for="outros"> Outros(especifique no campo de adendo)</label></br>
  </fieldset> 

	<fieldset id="Adendo"> <legend>Adendo</legend>
    <textarea name="tMsg" id="cMsg" cols="35"
    rows="5" placeholder="Escreva aqui um adendo para sua denuncia"> </textarea>
</br>
    <input type="submit" value="Enviar Denuncia">

  </fieldset>

</div>
</div>
</body>
</html>