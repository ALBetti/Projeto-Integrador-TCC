<!DOCTYPE html>
<html>
<head>
	<div id="Fundo-externo">		
	<div id="Fundo">		
	</div>
	<meta charset="UTF-8">
	<title>Perfil</title>
    <link rel="stylesheet" type="text/css" href="PaginaPerfil_Projeto.css">
</head>
<body>
	<nav id="Paginas">
		<ul>
			<li><a href="PaginaInicial_Projeto.php">Inicio</a></li>
			<li><a href="PaginaChat_Projeto.php">Chat</a></li>
			<li><a href="PaginaGrupos_Projeto.php">Grupos</a></li>
			<li><a href="PaginaAjuda_Projeto.php">Ajuda</a></li>
			<li><a href="PaginaBusca_Projeto.php">Busca</a></li>
			<li><a href="PaginaDenuncias_Projeto.php">Denuncias</a></li>
			<li><a href="PaginaMeuPerfil_Projeto.php">Perfil</a></li>
			</ul>		
	</nav>	
	<div class="centro">
	<div class="box1">

	<p class="img"><img src="Kermit_na_Bad.png" alt="DR.Eduardo" title="Dr.Eduardo" width="30%" height="30%" border="1px"  /></p>
</br>
<h1>Nome de Usuario: Dr. Eduardo</h1>
</br>
<p>Sexo: Masculino</p>
</br>
<p>Idade: 22 anos</p>
</br>
<p>Telefone: 90905-1802</p>
</br>
<p>Tipo de usuario: Profissional</p>

</div>
</div>
</body>
</html>