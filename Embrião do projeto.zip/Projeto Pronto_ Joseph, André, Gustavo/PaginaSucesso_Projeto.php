<!DOCTYPE html>
<html>
<head>
	<div id="Fundo-externo">		
	<div id="Fundo">		
	</div>
	<meta charset="UTF-8">
	<title>:D</title>
	<link rel="stylesheet" type="text/css" href="PaginaSucesso_Projeto.css">
</head>
<body>
	<div class="centro">
	<div class="box1">
<h1>Senha redefinida com sucesso!!!</h1>
</br>
</br>
</br>
<p><a href="PaginaPrincipal_Projeto.php">Voltar ao Inicio</a></p>

</div>
</div>
</body>
</html>