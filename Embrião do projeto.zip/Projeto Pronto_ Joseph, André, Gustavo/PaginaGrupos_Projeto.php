<!DOCTYPE html>
<html>
<head>
	<div id="Fundo-externo">		
	<div id="Fundo">		
	</div>
	<meta charset="UTF-8">
	<title>DigaNãoaDepressão</title>
    <link rel="stylesheet" type="text/css" href="PaginaGrupos_Projeto.css">
</head>
<body>
		<nav id="Paginas">
		<ul>
			<li><a href="PaginaInicial_Projeto.php">Inicio</a></li>
			<li><a href="PaginaChat_Projeto.php">Chat</a></li>
			<li><a href="PaginaAjuda_Projeto.php">Ajuda</a></li>
			<li><a href="PaginaBusca_Projeto.php">Busca</a></li>
			<li><a href="PaginaDenuncias_Projeto.php">Denuncias</a></li>
			<li><a href="PaginaMeuPerfil_Projeto.php">Perfil</a></li>
		</ul>		
	</nav>
	<div class="centro">

	<div class="box1">
<?php
$gp = 1;// aqui o codigo consultaria o banco para verificar se o usuario pertence a um grupo, caso sim o $gp é 1, caso não $gp é 0
if ($gp < 1) {

?>
<h1>Não Participa de nenhum grupo?</h1>
<h1> Aqui estão alguns grupos recomendados para você!</h1>
<nav id="Grupos">
	<ul>
		<li><a> Solução para a Bipolaridade</a></li>
		<li><a> Unidos Contra a Depressão</a></li>
		<li><a> Acalmando a Ansiedade</a></li>
		<li><a> Grupo Geral de Ajuda</a></li>
</br>
</br>
		<form action="PaginaParticipar_Projeto.php">		
		<li><a id=butao><input type="submit" value="Participar"></a></li>
		<li><a id=butao><input type="submit" value="Participar"></a></li>
		<li><a id=butao><input type="submit" value="Participar"></a></li>
		<li><a id=butao><input type="submit" value="Participar"></a></li>
		</form>
	</ul>
</nav>
</br>
<?php 
}
else {
?>
<div class="box2">
	<form method="post" action="<?php echo $_SERVER['PHP_SELF']?>">
	<h1>Ajuda para pessoas com depressão</h1>
<fieldset>
	<h3>Doutora Tamyres disse:</h3>
	<p> Se precisarem de ajuda, to sempre disponivel.</p>
	<h3>José Disse:</h3>
	<p> Ah que bom!</p>
	<p> Obrigado Doutora</p>
	<h3>Doutora Tamyres disse:</h3>
	<p> Por Nada</p>
	<h3>Administrador Joseph Disse:</h3>
	<p>Só passando para avisar que removi Gustavo do grupo por causa de Spam...</p>
    <h3>Você:</h3> 
     <?php
     $Mens = $_POST['tMenG'];
     echo $Mens;
     ?>
	</br>
	<fieldset id="MensagemG"> 
   <p>Mensagem<input type="text" name="tMenG" id="cMenG" size="60"
 	 maxlength="60" placeholder="Escreva aqui" type="cMenG" required/> </p>
 	<input type="submit" value="Enviar Mensagem">
	</fieldset>
	</fieldset>
</div>
<?php 
}
?>
</div>
</div>
</body>
</html>