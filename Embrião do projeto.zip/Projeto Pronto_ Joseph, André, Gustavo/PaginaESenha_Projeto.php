<!DOCTYPE html>
<html>
<head>
	<div id="Fundo-externo">		
	<div id="Fundo">		
	</div>
	<meta charset="UTF-8">
	<title>Recuperar Senha</title>
    <link rel="stylesheet" type="text/css" href="PaginaESenha_Projeto.css">
</head>
<body>
<div class="centro">
	<div class="box1">
<h1>Esqueci Minha Senha</h1>
</br>
</br>
	<?php
	$nome = $_POST['tNome'];
	$email = $_POST['tEmail'];	
	if (//condição para enviar o email
	$nome) {
		//estrutura que envia email aqui

ini_set('display_errors', 1);

error_reporting(E_ALL);

$from = "josephhgodin@gmail.com";

$to = $email;

$subject = "Cadastro em Dnad";

$message = "Olá". $nome ."aqui está o link para que possa redefinir sua senha. Se não deseja mudar sua senha, por favor, ignore esse email.";
//aqui não tem o link pois  não como redefinir uma senha sem usar banco
$headers = "De:". $from;

mail($to, $subject, $message, $headers);
		
    ?>
	<h1>Email com link enviado!</h1>
 	<?php	
	}
	elseif(//condição que endica que o digitado esta incorreto
		$nome = $email)
	 {
	 	?>
	<h1>Nome de usuario ou Email incorretos, não foi possivel enviar o link.</h1>
	<?php
 	
	 }
	?>
	<form method="post" action="<?php echo $_SERVER['PHP_SELF']?>">

	<p>Esqueceu sua senha? Tudo bem, não se preocupe isso acontece com todo mundo. 
	Nos diga seu nome de usuario e email, vamos mandar um link para seu email onde poderá redefinir sua senha. </p>
</br>
	  <p>Nome: <input type="text" name="tNome" id="cNome" size="20"
  maxlength="30" placeholder="Nome Completo" type="cNome" requiredss/> </p>

  <p>E-mail: <input type="email" name="tMail" id="cMail" size="20" maxlength="40" placeholder="Blablabla@emailzin.com" type="cMail" required /></p>
</br>
  <p><input type="submit" value="Redefinir Senha"></p>

</div>
</div>
</body>
</html>
