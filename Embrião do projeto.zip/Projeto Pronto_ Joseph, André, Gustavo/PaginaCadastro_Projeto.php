<!DOCTYPE html>
<html>
<head>
  <div id="Fundo-externo">    
  <div id="Fundo">    
  </div>
	<meta charset="UTF-8">
	<title>Cadastrar</title>
  <link rel="stylesheet" type="text/css" href="PaginaCadastro_Projeto.css">
</head>
<body>
  <div class="centro">
  <div class="box1">
<h1>Cadastro</h1>

<fieldset id="cadastro"><legend>Cadastro de usuarios</legend>

	<form method="post" action="PaginaConfirmar_Projeto.php">

  <p>Nome: <input type="text" name="tNome" id="cNome" size="20"
  maxlength="30" placeholder="Nome Completo" type="cNome" required/> </p>

  <p>E-mail: <input type="email" name="tMail" id="cMail" size="20" maxlength="40" placeholder="Blablabla@emailzin.com" type="cMail" required /></p>

  <p>Senha: <input type="password" name="tSenha" id="cSenha" size="20"
  maxlength="30" placeholder="Senha" type="cSenha" required/> </p>
  
  <fieldset id="Sexo"> <legend>Sexo</legend></br>
        <input type="radio" name="tSexo" id="cMasc" required/>
        <label for="cMasc"> Masculino</label> </br>
        <input type="radio" name="tSexo" id="cFem" required/>
        <label for="cFem"> Feminino</label>
        <input type="radio" name="tSexo" id="Outros" required/>
        <label for="outros"> Outro</label></br>
  </fieldset> 

  <p>Data de nascimento: <input type="date" name="tNasc" id="cNasc" required/></p>
  
  <p>Telefone: <input type="tel" id="cFone" name="tFone" placeholder="(xxxxx-xxxx)" pattern="^\d{5}-\d{4}$" required /> </p>
 
  <fieldset id="Tipo"> <legend>Tipo de usuario</legend></br>
        <input type="radio" name="tTipo" id="cComum" required/>
        <label for="cComum"> Comum</label> </br>
        <p>Caso esteja com problemas e procura ajuda</p>
        <input type="radio" name="tTipo" id="cAjudante" required/>
        <label for="cAjudante"> Ajudante</label>
        <p>Caso queira ajudar quem tem problemas</p>
        <input type="radio" name="tTipo" id="cProfissional" required/>
        <label for="cProfissional"> Profissional</label></br>
        <p>Caso seja um Profissional na area e queira ajudar as pessoas por esse site</p>
  </fieldset> 
  </fieldset>
  <input type="submit" value="Pronto!">

</form>
</fieldset>
</div>
</div>
</body>
</html>