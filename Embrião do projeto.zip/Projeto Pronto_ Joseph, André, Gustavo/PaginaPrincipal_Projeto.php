<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>DigaNãoadepressão</title>
	<link rel="stylesheet" type="text/css" href="PaginaPrincipal_Projeto.css">
</head>
<body>
<div class="centro">
		<div class="box1">
	<?php
	$nome = $_POST['tNome'];
	$senha = $_POST['tSenha'];
	if (//meio de confirmar que o nome e senha estâo de acordo com o banco
	$senha) {
		//meio de enviar a pessoa pra pagina inicial automaticamente
		?>
 	<?php	
	}
	elseif(//condição que endica que o digitado esta incorreto
		$nome = $senha)
	 {
	 	?>
	<h1>Nome de usuario ou senha incorretos</h1>
	<?php
 	
	 }
	?>
	<h1>Bem vindo ao Diga Não A Depressão!</h1>
</br>
	<p class="img"><img src="LogoBalão_A.png" alt="DNAD" title="DigaNãoADepressão" width="20%" height="20%" border="1px"  /></p>
</br>
	<p>Esse site foi feito com o intuito de ajudar pessoas que passam por transtornos mentais, não só a depressão, como também a ansiedade e a Bipolaridade!</p>
</br>
</br>
	<h2>
		Entrar
	</h2>
 	<form action="PaginaInicial_Projeto.php">
 	<fieldset id="usuario"><legend>Identificação de usuario</legend>
	<form method="post" action="PaginaInicial_Projeto.php">
 	 <p>Nome: <input type="text" name="tNome" id="cNome" size="20"
 	 maxlength="30" placeholder="Nome Completo" type="cNome" required/> </p>
 	 <p>Senha: <input type="password" name="tSenha" id="cSenha" size="20"
 	 maxlength="30" placeholder="Senha" type="cSenha" required/> </p>
 	  <input type="submit" value="Entrar">
 	</br>
 </br>
	<nav id="Cadastro">
		<ul>
			<li><a href="PaginaESenha_Projeto.php">Esqueci minha senha</a></li>
			<li><a href="PaginaCadastro_Projeto.php">Cadastrar</a></li>
		</ul>		
	</nav>
</fieldset>

</div>
</div>
</body>
</html>