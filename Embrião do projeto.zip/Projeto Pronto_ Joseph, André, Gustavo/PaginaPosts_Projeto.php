<!DOCTYPE html>
<html>
<head>
	<div id="Fundo-externo">		
	<div id="Fundo">		
	</div>
	<meta charset="UTF-8">
	<title>Seus Posts</title>
    <link rel="stylesheet" type="text/css" href="PaginaPosts_Projeto.css">
</head>
<body>
	<nav id="Paginas">
		<ul>

			<li><a href="PaginaInicial_Projeto.php">Inicio</a></li>
			<li><a href="PaginaChat_Projeto.php">Chat</a></li>
			<li><a href="PaginaGrupos_Projeto.php">Grupos</a></li>
			<li><a href="PaginaAjuda_Projeto.php">Ajuda</a></li>
			<li><a href="PaginaBusca_Projeto.php">Busca</a></li>
			<li><a href="PaginaDenuncias_Projeto.php">Denuncias</a></li>
            <li><a href="PaginaMeuPerfil_Projeto.php">Perfil</a></li>
		</ul>		
	</nav>
	<div class="centro">
	<div class="box1">
		<h1>Meus Posts</h1>
</br>
    <fieldset>
    <p>O Mestre na arte da vida faz pouca distinção entre o seu trabalho e o seu lazer, entre a sua mente e o seu corpo, entre a sua educação e a sua recreação, entre o seu amor e a sua religião. Ele dificilmente sabe distinguir um corpo do outro. Ele simplesmente persegue sua visão de excelência em tudo que faz, deixando para os outros a decisão de saber se está trabalhando ou se divertindo. Ele acha que está sempre fazendo as duas coisas simultaneamente. 
    Textos Budistas</p>
</br>
     <form action="<?php echo $_SERVER['PHP_SELF']?>">
     <fieldset id="Comentarios"> <legend>Comentarios</legend>
     <p>Fernando comentou:</p>
     <p>hum... isso me colocou para pensar</p>
     <?php
     echo "Você";
     $Coment = $_POST['tComent'];
     echo $Mens;
     ?>
     <fieldset id="Comentar"> 
     <p>Comentar<input type="text" name="tComent" id="cComent" size="60"
 	 maxlength="30" placeholder="Escreva aqui" type="cComent" required/> </p>
 	 <input type="submit" value="Postar Comentario">
 	</fieldset>
 	</fieldset>
    </fieldset>
</form>
</br>
	<fieldset>
    <p>Não dá para nutrir sentimentos como hostilidade, ciúme, medo, culpa, depressão. Essas são emoções tóxicas. Importante: onde há prazer, há a semente da dor, e vice-versa. O segredo é o movimento: não ficar preso na dor, nem no prazer (que então vira vício). Não se deve reprimir ou evitar a dor, mas tomar responsabilidade sobre ela.</p>
</br>
    <form action="<?php echo $_SERVER['PHP_SELF']?>">
     <fieldset id="Comentarios"> <legend>Comentarios</legend>
     <p>Eduarda comentou:</p>
     <p>Então mudar minha rotina me ajudará a melhorar?</p>
     <?php
     echo "Você";
     $Coment = $_POST['tComent'];
     echo $Mens;
     ?>
     <fieldset id="Comentar"> 
     <p>Comentar<input type="text" name="tComent" id="cComent" size="60"
 	 maxlength="30" placeholder="Escreva aqui" type="cComent" required/> </p>
 	 <input type="submit" value="Postar Comentario">
 	</fieldset>
 	</fieldset>
 	</fieldset>
 </form>
</br>
<?php

     $Post = $_POST['tMsg'];
if ($Post) { 
	?>
	<fieldset>
		<?php
     echo $Post;
     ?>
</br>
     <form action="<?php echo $_SERVER['PHP_SELF']?>">
     <fieldset id="Comentarios"> <legend>Comentarios</legend>
     <?php
     echo "Você";
     $Coment = $_POST['tComent'];
     echo $Mens;
     ?>     
     <fieldset id="Comentar"> 
     <p>Comentar<input type="text" name="tComent" id="cComent" size="60"
 	 maxlength="30" placeholder="Escreva aqui" type="cComent" required/> </p>
 	 <input type="submit" value="Postar Comentario">
 	</fieldset>
 	</fieldset>
 	</fieldset>
 </form>
</br>
<?php 
}
?>
	<fieldset id="Posts"> <legend>Criar Post</legend>

 	 <p><textarea name="tMsg" id="cMsg" cols="35"
    rows="5" placeholder="Escreva o conteudo do post aqui."> </textarea> </p>
     	   <input type="submit" value="Postar">
     	   </br>
     	</fieldset>

</div>
</div>
</body>
</html>