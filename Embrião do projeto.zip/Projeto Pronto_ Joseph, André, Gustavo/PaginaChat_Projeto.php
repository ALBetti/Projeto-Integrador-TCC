<!DOCTYPE html>
<html>
<head>
	<div id="Fundo-externo">		
	<div id="Fundo">		
	</div>
	<meta charset="UTF-8">
	<title>Chat</title>
    <link rel="stylesheet" type="text/css" href="PaginaChat_Projeto.css">
</head>
<body>
	<nav id="Paginas">
		<ul>
			<li><a href="PaginaInicial_Projeto.php">Inicio</a></li>
			<li><a href="PaginaGrupos_Projeto.php">Grupos</a></li>
			<li><a href="PaginaAjuda_Projeto.php">Ajuda</a></li>
			<li><a href="PaginaBusca_Projeto.php">Busca</a></li>
			<li><a href="PaginaDenuncias_Projeto.php">Denuncias</a></li>
			<li><a href="PaginaMeuPerfil_Projeto.php">Perfil</a></li>
		</ul>		
	</nav>
	<div class="centro">
	<div class="box1">	
<h1>Conversa com <a href="PaginaPerfil_Projeto.php">Dr. Eduardo</a></h1>
</br>
	<form method="post" action="<?php echo $_SERVER['PHP_SELF']?>">
	<fieldset>
	<h3>Dr. Eduardo disse:</h3>
	<p> Tudo vai dar certo.</p>
	<h3>Você Disse:</h3>
	<p> Tem certeza?</p>
	<h3>Dr. Eduardo disse:</h3>
	<p> Sim</p>
	<p> Tenho certeza</p>
	<h3>Você:</h3>
     <?php
     $Mens = $_POST['tMenG'];
     echo $Mens;
     ?>
	</br>
	<fieldset id="Mensagem"> 
    <p>Mensagem<input type="text" name="tMenG" id="cMenG" size="60"
 	 maxlength="30" placeholder="Escreva aqui" type="cMenG" requiredss/> </p>
 	<input type="submit" value="Enviar Mensagem">
 </fieldset>
</fieldset>

</div>
</div>
</div>
</body>
</html>