<!DOCTYPE html>
<html>
<head>
	<div id="Fundo-externo">		
	<div id="Fundo">		
	</div>
	<meta charset="UTF-8">
	<title>Busca</title>
    <link rel="stylesheet" type="text/css" href="PaginaBusca_Projeto.css">
</head>
<body>
	<nav id="Paginas">
		<ul>
			<li><a href="PaginaInicial_Projeto.php">Inicio</a></li>
			<li><a href="PaginaChat_Projeto.php">Chat</a></li>
			<li><a href="PaginaGrupos_Projeto.php">Grupos</a></li>
			<li><a href="PaginaAjuda_Projeto.php">Ajuda</a></li>
			<li><a href="PaginaDenuncias_Projeto.php">Denuncias</a></li>
			<li><a href="PaginaMeuPerfil_Projeto.php">Perfil</a></li>
		</ul>		
	</nav>
	<div class="centro">
	<div class="box1">
	<?php
	$busca = $_POST['tbusca'];
	if ($nada){
	//condição que a busca deu certo
		Print"Resultados encontrados";
		echo $table;	
	}
	elseif($busca = 1){
	//condição que indica que o digitado esta incorreto	
	 	?>
	<h1>Desculpe não encontramos nada, tente novamente.</h1>
	<?php
 	
	 }
	?>
<p><a href="PaginaBusca_Projeto.php">Voltar</a></p>


</div>
</div>
</body>
</html>
