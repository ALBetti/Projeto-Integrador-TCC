<!DOCTYPE html>
<html>	
	<div id="Fundo-externo">		
	<div id="Fundo">		
	</div>
	<meta charset="UTF-8">
	<title>DigaNãoaDepressão</title>
    <link rel="stylesheet" type="text/css" href="PaginaInicial_Projeto.css">
</head>
<body>
	<nav id="Paginas">
		<ul>
			<li><a href="PaginaChat_Projeto.php">Chat</a></li>
			<li><a href="PaginaGrupos_Projeto.php">Grupos</a></li>
			<li><a href="PaginaAjuda_Projeto.php">Ajuda</a></li>
			<li><a href="PaginaBusca_Projeto.php">Busca</a></li>
			<li><a href="PaginaDenuncias_Projeto.php">Denuncias</a></li>
			<li><a href="PaginaMeuPerfil_Projeto.php">Perfil</a></li>
		</ul>		
	</nav>
<div class="centro">
	<div class="box1">

<h1>Grupos Recomendados</h1>
<nav id="Grupos">
	<ul>
		<li><a> Solução para a Bipolaridade</a></li>
		<li><a> Unidos Contra a Depressão</a></li>
		<li><a> Acalmando a Ansiedade</a></li>
		<li><a> Grupo Geral de Ajuda</a></li>
</br>
</br>
	<form action="PaginaParticipar_Projeto.php">
		<li><a id=butao><input type="submit" value="Participar"></a></li>
		<li><a id=butao><input type="submit" value="Participar"></a></li>
		<li><a id=butao><input type="submit" value="Participar"></a></li>
		<li><a id=butao><input type="submit" value="Participar"></a></li>
</form>
	</ul>
</nav>

	<div class="box2">
<h1>Posts</h1>
</br>
    <fieldset>
    	<h3>Post de Dr. Eduardo</h3>
    <p>O Mestre na arte da vida faz pouca distinção entre o seu trabalho e o seu lazer, entre a sua mente e o seu corpo, entre a sua educação e a sua recreação, entre o seu amor e a sua religião. Ele dificilmente sabe distinguir um corpo do outro. Ele simplesmente persegue sua visão de excelência em tudo que faz, deixando para os outros a decisão de saber se está trabalhando ou se divertindo. Ele acha que está sempre fazendo as duas coisas simultaneamente. 
    Textos Budistas</p>
</br>
     	<form method="post" action="<?php echo $_SERVER['PHP_SELF']?>">
		<fieldset id="Comentarios"> <legend>Comentarios</legend>
     <p>Fernando comentou:</p>
     <p>hum... isso me colocou para pensar</p>
     <?php
     print "Você comentou:";
	  $Com = $_POST['tComent'];
	  ?>
	  </br>
	  </br>
	  <?php
	  print "$Com";
     ?>
     <fieldset id="Comentar"> 
     <p>Comentar<input type="text" name="tComent" id="cComent" size="60"
 	 maxlength="30" placeholder="Escreva aqui" type="cComent" requiredss/> </p>
 	 <input type="submit" value="Postar Comentario">
	</form>
 	</fieldset>
 	</fieldset>
 	</fieldset>
</br>
	<fieldset>
	<h3>Post de Dr. Eduardo</h3>
    <p>Não dá para nutrir sentimentos como hostilidade, ciúme, medo, culpa, depressão. Essas são emoções tóxicas. Importante: onde há prazer, há a semente da dor, e vice-versa. O segredo é o movimento: não ficar preso na dor, nem no prazer (que então vira vício). Não se deve reprimir ou evitar a dor, mas tomar responsabilidade sobre ela.</p>
</br>
     <form action="<?php echo $_SERVER['PHP_SELF']?>">
     <fieldset id="Comentarios"> <legend>Comentarios</legend>
     <p>Eduarda comentou:</p>
     <p>Então mudar eu devo equilibrar minha emoçoes ruins e boas para melhorar?</p>
     <?php
     print "Você comentou:";
	  $Com = $_POST['tComent'];
	  ?>
	  </br>
	  </br>
	  <?php
	  print "$Com";
     ?>
     <fieldset id="Comentar"> 
     <p>Comentar<input type="text" name="tComent" id="cComent" size="60"
 	 maxlength="30" placeholder="Escreva aqui" type="cComent" requiredss/> </p>
 	 <input type="submit" value="Postar Comentario">
 	</form>
 	</fieldset>
 	</fieldset>
 	</fieldset>
</br>
	<fieldset id="Posts"> <legend>Meus Posts</legend>
	<form action="PaginaPosts_Projeto.php">
	<p>Deseja ver seus posts? (apenas Profissional e administrador)</p>	
 	 <input type="submit" value="Meus Posts"> 
 	 </fieldset>	
</div>
</div>
</div>
</body>
</html>
